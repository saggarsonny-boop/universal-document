# Universal Document™ iSDK v1.0

Embed the Universal Document™ Reader in any web application with three lines of code.

## Quick Start

```html
<script src="https://ud.hive.baby/isdk/ud-isdk.js"></script>
<ud-reader src="your-document.uds"></ud-reader>
<link rel="stylesheet" href="https://ud.hive.baby/isdk/ud-isdk.css">
```

That's it. The `<ud-reader>` element handles everything: rendering, clarity layer switching, expiry checking, revocation validation, and chain-of-custody display.

## Attributes

| Attribute | Type | Description |
|-----------|------|-------------|
| `src` | string | URL or path to a .uds or .udr file |
| `theme` | `light` \| `dark` \| `auto` | Colour scheme (default: `auto`) |
| `lang` | string | Preferred language code (default: document default) |
| `show-chain` | boolean | Show chain-of-custody panel (default: false) |
| `readonly` | boolean | Disable editing for .udr files (default: false) |

## JavaScript API

```js
const reader = document.querySelector('ud-reader')

// Load a document
reader.load('path/to/document.uds')

// Get metadata
const meta = await reader.getMetadata()
// → { title, format, status, expires_at, revoked, ... }

// Switch clarity layer
reader.setLayer('patient_summary')  // or 'clinical', 'legal', etc.

// Listen for events
reader.addEventListener('ud:loaded',  e => console.log('Loaded', e.detail))
reader.addEventListener('ud:expired', e => console.log('Document expired'))
reader.addEventListener('ud:revoked', e => console.log('Document revoked'))
```

## What is Universal Document™?

Universal Document™ is an open document format with three file types:
- `.uds` — Universal Document Sealed. Tamper-evident, immutable.
- `.udr` — Universal Document Revisable. Editable draft.
- `.udz` — Universal Document Bundle. Governed collection of .uds files.

Learn more at https://ud.hive.baby

## Sample File

`sample.uds` in this package is a valid sealed Universal Document™. Use it to test the iSDK integration.

## Support

- Documentation: https://ud.hive.baby/isdk
- Issues: https://github.com/saggarsonny-boop/universal-document/issues
- Email: hive@hive.baby

## License

Apache 2.0 — see LICENSE file.

Universal Document™ is a pending trademark (Serial 99774346).
