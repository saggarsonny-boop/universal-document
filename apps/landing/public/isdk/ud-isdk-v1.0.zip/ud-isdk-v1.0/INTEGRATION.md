# iSDK Integration Guide

## Three-line embed

```html
<script src="https://ud.hive.baby/isdk/ud-isdk.js"></script>
<ud-reader src="your-document.uds"></ud-reader>
<link rel="stylesheet" href="https://ud.hive.baby/isdk/ud-isdk.css">
```

## React

```jsx
import { UDReader } from '@universal-document/isdk-react'

export default function App() {
  return <UDReader src="/documents/report.uds" theme="light" />
}
```

## Next.js

```jsx
import dynamic from 'next/dynamic'
const UDReader = dynamic(() => import('@universal-document/isdk-react'), { ssr: false })

export default function Page() {
  return <UDReader src="/report.uds" showChain />
}
```

## Vue

```vue
<template>
  <ud-reader src="/document.uds" theme="auto" />
</template>

<script setup>
import '@universal-document/isdk-vue'
</script>
```

## Events

```js
const reader = document.querySelector('ud-reader')
reader.addEventListener('ud:loaded',  ({ detail }) => console.log('Title:', detail.title))
reader.addEventListener('ud:expired', () => alert('This document has expired'))
reader.addEventListener('ud:revoked', () => alert('This document has been revoked'))
```

## CDN URLs

| Asset | URL |
|-------|-----|
| JS | https://ud.hive.baby/isdk/ud-isdk.js |
| CSS | https://ud.hive.baby/isdk/ud-isdk.css |
| React | npm install @universal-document/isdk-react |
| Vue | npm install @universal-document/isdk-vue |

## Support

Documentation: https://ud.hive.baby/isdk  
Issues: https://github.com/saggarsonny-boop/universal-document  
Email: hive@hive.baby
